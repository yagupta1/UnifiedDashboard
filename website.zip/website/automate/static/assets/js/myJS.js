function getBuilds()
        {
            $.ajax({
                url: 'Builds/',
                type: 'POST',
                dataType: 'json',
                data: {
                    data: { CSRF: getCSRFTokenValue()}
                    //csrfmiddlewaretoken: '{{ csrf_token }}'
                },
                success: function (data) {
                    var len = data.length;
                    alert(data);

                    /*
                    var items = "";
                    for(var i=0;i<len;i++)
                    {
                        items+="<option value='"+data[i].Date +"'>"+data[i].Date +"</option>";
                    }
                    $("#builds").append(items);
                    */
                    //alert(data[0].Date);
                },
                error: function(xhr, status, error) {
                    //var err = eval("(" + xhr.responseText + ")");
                    alert("Error");
                    //alert(xhr.responseText);
                }
            });
        }


def fun():
    path="C:\Users\yagupta\Desktop\website\automate\Automation Reports\trial.html"
    print(path)

fun();


'''
def __str__(self):
    return self.name.encode('utf8')
'''

from django.db import models


class BuildReports(models.Model):
    BuildNo = models.CharField(max_length=250, primary_key=True)
    ReportPath = models.CharField(max_length=500)



class BuildInstaller(models.Model):
    BuildNo = models.CharField(max_length=250, primary_key=True)
    Platform = models.CharField(max_length=250)

class ReportStatus(models.Model):
    Date = models.CharField(max_length = 250, primary_key=True)
    PSEStatus = models.BooleanField(default=False)
    PREStatus = models.BooleanField(default=False)
    EOStatus = models.BooleanField(default=False)
    HubStatus = models.BooleanField(default=False)
    ACStatus = models.BooleanField(default=False)

class ReportPath(models.Model):
    BuildNo = models.CharField(max_length=250)
    Product = models.CharField(max_length=250)
    Path = models.CharField(max_length=250)

'''
class TCResults(models.Model):
    ID = models.IntegerField(default=0, primary_key=True)
    TaskID = models.IntegerField()
    TaskDate = models.CharField(max_length=250)
    TestCaseID = models.IntegerField()
'''


################## Starts here #################

class Builds_Installed(models.Model):
    BuildNo = models.CharField(max_length=250)

class Builds_Status(models.Model):
    BuildNo = models.CharField(max_length=250)
    PSEStatus = models.BooleanField(default=False)
    PREStatus = models.BooleanField(default=False)
    EOStatus = models.BooleanField(default=False)
    HubStatus = models.BooleanField(default=False)
    ACStatus = models.BooleanField(default=False)

    Installer_PSEStatus = models.BooleanField(default=False)
    Installer_PREStatus = models.BooleanField(default=False)
    PeopleStatus = models.BooleanField(default=False)
    Video_taggingStatus = models.BooleanField(default=False)
    Launch_numbersStatus = models.BooleanField(default=False)
    OLSStatus = models.BooleanField(default=False)

class Builds_Info(models.Model):
    BuildNo = models.CharField(max_length=250)
    Product = models.CharField(max_length=250)
    DateTime = models.DateTimeField(max_length=250)
    Report = models.CharField(max_length=250)

class Product_Paths(models.Model):
    Product = models.CharField(max_length=150)
    Path = models.CharField(max_length=450)



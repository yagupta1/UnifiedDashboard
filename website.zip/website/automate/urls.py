from django.conf.urls import url, re_path
from django.urls import path
from . import views


app_name = 'automate'

urlpatterns = [
    path('', views.index, name='index'),

    path('Builds/', views.getBuilds, name='getBuilds'),

    path('Report/', views.fetchReport, name='fetchReport'),

    url(r'^Build/1/2/3/(?P<buildno>\D(\d{8})\D\.m\.\D(\d{6})\D)/$', views.searchBuildNo, name='searchBuildNo'),

    #Automation Reports/<prodfolder>/<report>/
    path('Automation Reports/<prodfolder>/<report>', views.displayLatestReport, name='displayLatestReport'),

    #<prod>/
    path('<prod>/', views.fetchLatestReport, name='fetchLatestReport'),

    #<prod>/<report>/
    path('<prod>/<report>/', views.displayLatestReport, name='displayLatestReport'),

    #<prod>/<func>/<reports>/
    path('<prod>/<func>/<reports>/', views.fetchTop10, name='fetchTop10'),

    #Builds/1/2/<buildno>/
    path('Builds/1/2/<buildno>/', views.fetchBuildReport, name='fetchBuildReport'),

    #Build/1/2/3/<buildno>/
    path('Build/1/2/3/<buildno>/', views.searchBuildNo, name='searchBuildNo'),

    #Build/1/2/3/4/<build>/
    path('Build/1/2/3/4/<build>/', views.displayTop10fromDD, name='displayTop10fromDD'),

]




from django.apps import AppConfig


class AutomateConfig(AppConfig):
    name = 'automate'

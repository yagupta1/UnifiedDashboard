
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, get_object_or_404

from .models import BuildReports

from .models import BuildInstaller
from .models import ReportStatus
from .models import ReportPath
from .models import Builds_Installed
from .models import Product_Paths
from .models import Builds_Status
from .models import Builds_Info
from django.db.models import Max

#from .models import TCResults
from django.http import JsonResponse
from django.conf import settings
import os
from django.core import serializers
#from BeautifulSoup import BeautifulSoup
import re
import glob
import os
import openpyxl

def index(request):
    #os.system('mklink /d "c:\\Users\\yagupta\\Desktop\\website\\automate\\Templates\\Repost" "\\\\indshare\\transfer\\Yachika\\Reports"')
    #data = list(BuildInstaller.objects.values_list('BuildNo'))
    '''
    print(data)
    builds = []
    for build_no in data:
        build_str = ''.join(build_no)
        build = build_str.replace("&#39;", "")
        builds.append(build)
    '''
    #return render(request, 'automate/trial.html', {"data": data})
    return render(request, 'automate/index.html')

def getBuilds(request):

    print("\n-------------------- Get builds --------------------")

    pseBuilds = []
    preBuilds = []
    pseReports = []
    preReports = []
    pse=[]
    pre=[]

    #print("Hello")
    pse = list(Builds_Installed.objects.filter(BuildNo__icontains='m').values('BuildNo'))
    pre = list(Builds_Installed.objects.filter(BuildNo__icontains='daily').values('BuildNo'))

    psePathList = list(Product_Paths.objects.filter(Product='PSE').values('Path'))
    prePathList = list(Product_Paths.objects.filter(Product='PRE').values('Path'))

    psePath = psePathList[0]['Path']
    prePath = prePathList[0]['Path']


    # Append PSE reports
    for i in range(len(pse)):
        #print("#######"+pse[i]['BuildNo']+"#########")
        buildno = pse[i]['BuildNo'].strip()
        #print("#######"+buildno+"#########")
        pseReportName = list(Builds_Info.objects.filter(Product='PSE', BuildNo=buildno).values('Report'))

        if(len(pseReportName)==0):
            pseReports.append("#")
        else:
            pseReports.append(psePath+pseReportName[0]['Report'])

    print(pseReports)


    # Append PRE reports
    for i in range(len(pre)):
        #print("#######"+pre[i]['BuildNo']+"#########")
        buildno = pre[i]['BuildNo'].strip()
        #print("#######"+buildno+"#########")
        preReportName = list(Builds_Info.objects.filter(Product='PRE', BuildNo=buildno).values('Report'))
        if (len(preReportName) == 0):
            preReports.append("#")
        else:
            preReports.append(prePath+preReportName[0]['Report'])

    print(preReports)



    #print(pse)
    #print(pre)
    for item in pse:
        pseBuilds.append(item)

    for item in pre:
        preBuilds.append(item)
    context = {
        'pseBuilds': pseBuilds,
        'preBuilds': preBuilds,
        'pseReports': pseReports,
        'preReports': preReports
    }
    return JsonResponse(context)

def fetchBuildReport(request, buildno):
    print("\n-------------------- Fetch build report --------------------")
    print("Build No.: "+buildno)
    productName = request.POST.get('product')
    print("Product Name: "+productName)


    path = list(Product_Paths.objects.filter(Product='Hub').values('Path'))
    ref_path = path[0]['Path']
    #print("Path: "+ref_path)

    build = Builds_Info.objects.filter(Product='Hub', BuildNo=buildno).aggregate(DateTime=Max('DateTime'))      #Change product from Hub to productName
    dt = build['DateTime']
    data = list(Builds_Info.objects.filter(Product='Hub', DateTime=dt, BuildNo=buildno).values('Report'))
    #print("Report: "+str(data))
    report = data[0]['Report']
    #print(report)


    context = {
        'Path': ref_path,
        'Report': report
    }

    return JsonResponse(context)


def fetchLatestReport(request, prod):
    print("\n-------------------- fetch latest report --------------------")
    if(prod=='Hub'):
        build = Builds_Info.objects.filter(Product='Hub').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='Hub', DateTime=dt).values('BuildNo','Report'))
        if(data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/Hub/'+report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)
    elif (prod == 'AC'):
        build = Builds_Info.objects.filter(Product='AC').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='AC', DateTime=dt).values('BuildNo', 'Report'))
        if (data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/AC/' + report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)
    elif (prod == 'EO'):
        build = Builds_Info.objects.filter(Product='EO').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='EO', DateTime=dt).values('BuildNo', 'Report'))
        if (data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/EO/' + report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)
    elif (prod == 'PSE'):
        build = Builds_Info.objects.filter(Product='PSE').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='PSE', DateTime=dt).values('BuildNo', 'Report'))
        if (data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/PSE/' + report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)
    elif (prod == 'OLS'):
        build = Builds_Info.objects.filter(Product='OLS').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='OLS', DateTime=dt).values('BuildNo', 'Report'))
        if (data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/OLS/' + report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)

    elif (prod == 'People'):
        build = Builds_Info.objects.filter(Product='People').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='People', DateTime=dt).values('BuildNo', 'Report'))
        if (data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/People/' + report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)

    elif (prod == 'Video_tagging'):
        build = Builds_Info.objects.filter(Product='Video_tagging').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='Video_tagging', DateTime=dt).values('BuildNo', 'Report'))
        if (data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/Video_tagging/' + report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)

    elif (prod == 'Launch_numbers'):
        build = Builds_Info.objects.filter(Product='Launch_numbers').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='Launch_numbers', DateTime=dt).values('BuildNo', 'Report'))
        if (data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/Launch_numbers/' + report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)

    elif (prod == 'Installer_PSE'):
        build = Builds_Info.objects.filter(Product='Installer_PSE').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='Installer_PSE', DateTime=dt).values('BuildNo', 'Report'))
        if (data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/Installer_PSE/' + report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)

    elif (prod == 'Installer_PRE'):
        build = Builds_Info.objects.filter(Product='Installer_PRE').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='Installer_PRE', DateTime=dt).values('BuildNo', 'Report'))
        if (data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/Installer_PRE/' + report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)

    else:
        build = Builds_Info.objects.filter(Product='PRE').aggregate(DateTime=Max('DateTime'))
        dt = build['DateTime']
        data = (Builds_Info.objects.filter(Product='PRE', DateTime=dt).values('BuildNo', 'Report'))
        if (data.exists()):
            build = data[0]['BuildNo']
            report = data[0]['Report']
            context = {
                'Build': build,
                'Report': 'automate/Automation Reports/PRE/' + report,
                'DateTime': dt
            }
        else:
            context = {
                'Build': "Null",
                'Report': "Null",
                'DateTime': "Null"
            }
        return JsonResponse(context)
        # path = "C:/Users/yagupta/Desktop/website/automate/Templates/automate/Automation Reports/PRE/*"

    '''
    list_of_files = glob.glob(path)  # * means all if need specific format then *.csv
    latest_file = max(list_of_files, key=os.path.getctime)
    print(latest_file)
    context = {
        'Report': latest_file
    }
    '''


def displayLatestReport(request, prodfolder, report):
    print("\n------------------- Display Latest Report ----------------------")
    #reportPath = 'automate/Automation Reports/' + str(prodfolder) + '/' + str(report)
    return HttpResponse(render(request, 'automate/Automation Reports/' + str(prodfolder) + '/' + str(report)))


def fetchTop10(request, prod, func, reports):
    print("\n--------------- Fetch Top10 -----------------")
    print(prod)
    print(func)
    print(reports)

    builds = []
    reports = []
    datetimes = []
    path = []
    if prod == "Hub":
        query = Builds_Info.objects.filter(Product='Hub').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='Hub').values('Path'))
    elif prod == "AC":
        query = Builds_Info.objects.filter(Product='AC').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='AC').values('Path'))
    if prod == "EO":
        query = Builds_Info.objects.filter(Product='EO').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='EO').values('Path'))
    if prod == "PSE":
        query = Builds_Info.objects.filter(Product='PSE').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='PSE').values('Path'))
    if prod == "PRE":
        query = Builds_Info.objects.filter(Product='PRE').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='PRE').values('Path'))
    if prod == "People":
        query = Builds_Info.objects.filter(Product='People').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='People').values('Path'))
    if prod == "Video_tagging":
        query = Builds_Info.objects.filter(Product='Video_tagging').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='Video_tagging').values('Path'))
    if prod == "Launch_numbers":
        query = Builds_Info.objects.filter(Product='Launch_numbers').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='Launch_numbers').values('Path'))
    if prod == "OLS":
        query = Builds_Info.objects.filter(Product='OLS').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='OLS').values('Path'))
    if prod == "Installer_PSE":
        query = Builds_Info.objects.filter(Product='Installer_PSE').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='Installer_PSE').values('Path'))
    if prod == "Installer_PRE":
        query = Builds_Info.objects.filter(Product='Installer_PRE').order_by("DateTime")[:10].values('BuildNo', 'Report', 'DateTime')
        path = list(Product_Paths.objects.filter(Product='Installer_PRE').values('Path'))

    ref_path = path[0]['Path']


    for rec in query:
        builds.append(rec['BuildNo'])
        reports.append(rec['Report'])
        datetimes.append(rec['DateTime'])
    context = {
        'Builds': builds,
        'Reports': reports,
        'DateTime': datetimes,
        'Path': ref_path
    }
    return JsonResponse(context)


def displayTop10fromDD(request, build):
    print("\n----------------- displayTop10 from Dropdown --------------------")

    query = Builds_Info.objects.filter(BuildNo=build).order_by("DateTime")[:10].values('Product', 'Report', 'DateTime')
    #path = list(Product_Paths.objects.filter(Product='Hub').values('Path'))

    paths = []
    products = []
    reports = []
    datetimes = []

    for rec in query:
        prod = rec['Product']
        path = list(Product_Paths.objects.filter(Product=prod).values('Path'))
        ref_path = path[0]['Path']
        paths.append(ref_path)
        products.append(prod)
        reports.append(rec['Report'])
        datetimes.append(rec['DateTime'])

    context = {
        'Products': products,
        'Paths': paths,
        'Reports': reports,
        'DateTime': datetimes
    }
    print("Products: "+str(products))
    print("Paths: " + str(paths))
    print("Reports: " + str(reports))
    print("DateTime: " + str(datetimes))

    return JsonResponse(context)


def searchBuildNo(request, buildno):
    print("\n-------------------- Search BuildNo. --------------------\n")
    print("Build No.: "+buildno)
    query = Builds_Info.objects.filter(BuildNo=buildno).values('Product', 'Report', 'DateTime')

    products = []
    reports = []
    paths = []
    datetimes = []

    for rec in query:
        prod = rec['Product']
        path = list(Product_Paths.objects.filter(Product=prod).values('Path'))
        ref_path = path[0]['Path']
        paths.append(ref_path)
        products.append(prod)
        reports.append(rec['Report'])
        datetimes.append(rec['DateTime'])

    context = {
        'Products': products,
        'Paths': paths,
        'Reports': reports,
        'DateTime': datetimes
    }
    return JsonResponse(context)


# Obsolete function.. the one used in trial.html
def fetchReport(request):

    print("\n-------------Fetch Report--------------")
    
    #queryset = BuildReports.objects.all()
    #queryset = queryset.filter(BuildNo__icontains=date)
    #dataset = BuildReports.objects.get(BuildNo='20190122.m.128309')
    #data = serializers.serialize('json', dataset)
    #repoPath = queryset.ReportPath
    #return HttpResponse("Hello")
    
    #data = list(BuildReports.objects.filter(BuildNo__icontains=date).values('ReportPath'))

    '''
    prods=[]
    paths=[]
    build = request.POST.get('Build')
    data = (ReportPath.objects.filter(BuildNo=build))
    for rec in data:
        prods.append(rec.Product)
        paths.append(rec.Path)
    context = {
        'prods': prods,
        'paths': paths
    }
    return JsonResponse(context)
    #return JsonResponse(data, safe=False)
    '''

'''
try:
    import cStringIO as StringIO
except ImportError:
    import StringIO

from django.http import HttpResponse
from xlsxwriter.workbook import Workbook


def display_XLS(request):
    # your view logic here

    # create a workbook in memory
    output = StringIO.StringIO()

    book = Workbook(output)
    sheet = book.add_worksheet('test')
    sheet.write(0, 0, 'Hello, world!')
    book.close()

    # construct response
    output.seek(0)
    response = HttpResponse(output.read(), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    response['Content-Disposition'] = "attachment; filename=test.xlsx"

    return response
'''
import codecs
import chardet
import io


filename='18.0 (20190805.m.136120)_WHATS_NEW_HUB_PEPE_PASS.html'

'''
with open(filename, 'r', encoding="ISO-8859-1").read() as f:
    print(f)
'''

with io.open(filename, 'r') as f:
    text = f.read()
## This writes the file as UTF 8
with io.open("a.html", 'w', encoding='utf8') as f:
    f.write(text)

## This tries to read the file again as UTF8 and this runs fine now

with io.open("a.html", 'r', encoding='utf8') as f:
    text = f.read()
    print(text)


'''
with codecs.open(filename, 'r', encoding = "ISO-8859-1").read() as fdata:
    print(fdata)
'''


'''
rawdata = open(filename, "r").read()
result = chardet.detect(rawdata)
print(result)
'''

'''
with codecs.open(filename, 'r').read().decode("Latin") as f:
    print(f)
'''


#print(chardet.detect(b'—')['encoding'])

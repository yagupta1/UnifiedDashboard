


from django.contrib import admin


from .models import BuildReports
from .models import BuildInstaller
from .models import ReportStatus
from .models import ReportPath
#from .models import TCResults


admin.site.register(BuildReports)
admin.site.register(BuildInstaller)
admin.site.register(ReportStatus)
admin.site.register(ReportPath)
#admin.site.register(TCResults)



################## Starts here #################

from .models import Builds_Installed
from .models import Builds_Status
from .models import Builds_Info
from .models import Product_Paths

admin.site.register(Builds_Installed)
admin.site.register(Builds_Status)
admin.site.register(Builds_Info)
admin.site.register(Product_Paths)







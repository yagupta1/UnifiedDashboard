import pyodbc
import sqlite3
from django.core.management.base import BaseCommand
from automate.models import Builds_Installed
from automate.models import Builds_Status

import os
import shutil
import time

from automate.models import Builds_Info



'''
############## Connect to sqlite3 ################
db = sqlite3.connect('C:/Users/yagupta/Desktop/website/db.sqlite3')
cursorSqlite = db.cursor()
'''

############## Create table in sqlite3 ################

'''
cursorSqlite.execute('CREATE TABLE automate_TCResults(TaskID INTEGER, TaskDate TEXT, TestCaseID INTEGER)')
db.commit()
'''

############## Connect to InstallerAutomation db and fetch the data ###############

cnxn = pyodbc.connect('DRIVER={SQL Server};SERVER=10.41.156.156\\SQLEXPRESS;DATABASE=InstallerAutomation;Integrated Security=True;UID=sa_kishan;PWD=P@$$word123')
#cnxn=pyodbc.connect("DRIVER={SQL SERVER};server=10.41.156.156\\SQLEXPRESS;database=InstallerAutomation;uid=sa_kishan;pwd=P@$$word123")
'''
cnxn = pyodbc.connect(driver='{SQL Server}', host='10.41.156.156\\SQLEXPRESS', database='InstallerAutomation',
                      trusted_connection=True, user='sa_kishan', password='P@$$word123')
                      '''
cursor = cnxn.cursor()
cursor1 = cnxn.cursor()
cursor.execute("SELECT BuildNumber FROM PSE_CheckBuild")
cursor1.execute("SELECT BuildNumber FROM PRE_CheckBuild")


############## Insert the fetched data into sqlite db ###############

class Command(BaseCommand):
    args = '<foo bar ...>'
    help = 'our help string comes here'

    def update_PSEBuilds(self):
        while 1:
            row = cursor.fetchone()
            if not row:
                break
            Build = row.BuildNumber
            
            if Builds_Installed.objects.filter(BuildNo=Build).exists():
                print("Duplicate")
            else:
                print("New")
                print(Build)
                entry_BI = Builds_Installed(BuildNo=Build)
                entry_BI.save()

                entry_BS = Builds_Status(BuildNo=Build, PSEStatus=False, PREStatus=False, EOStatus=False, HubStatus=False, ACStatus=False, Installer_PSEStatus=False, Installer_PREStatus=False, PeopleStatus=False, Video_taggingStatus=False, Launch_numbersStatus=False, OLSStatus=False)
                entry_BS.save()
                print("Saved")

    def update_PREBuilds(self):
        while 1:
            row = cursor1.fetchone()
            if not row:
                break
            Build = row.BuildNumber
            
            if Builds_Installed.objects.filter(BuildNo=Build).exists():
                print("Duplicate")
            else:
                print("New")
                print(Build)
                entry_BI = Builds_Installed(BuildNo=Build)
                entry_BI.save()

                entry_BS = Builds_Status(BuildNo=Build, PSEStatus=False, PREStatus=False, EOStatus=False, HubStatus=False, ACStatus=False, Installer_PSEStatus=False, Installer_PREStatus=False, PeopleStatus=False, Video_taggingStatus=False, Launch_numbersStatus=False, OLSStatus=False)
                entry_BS.save()
                print("Saved")
           
    def handle(self, *args, **options):
        self.update_PSEBuilds()
        self.update_PREBuilds()


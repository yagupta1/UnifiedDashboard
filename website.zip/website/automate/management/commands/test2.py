import os
import time

import pyodbc
import sqlite3
from django.core.management.base import BaseCommand
from automate.models import Builds_Status
from django.db.models import Max



class Command(BaseCommand):
    args = '<foo bar ...>'
    help = 'our help string comes here'

    def update_BuildStatus(self):
        #maxDate = Builds_Info.objects.all().aggregate(Max('DateTime'))
        #print(maxDate)

        #entry_BS = Builds_Status(BuildNo='20190415.daily.1835111', PSEStatus=False, PREStatus=False, EOStatus=False, HubStatus=False, ACStatus=False)
        #entry_BS.save()
        print("Hello")

        
    def handle(self, *args, **options):
        self.update_BuildStatus()







import os
import shutil
import time
import pandas as pd

import pyodbc
import sqlite3
from django.core.management.base import BaseCommand
from automate.models import Builds_Status
from automate.models import Builds_Info


############ Define source & destination ##############

#original_working_directory = os.getcwd()
#src = r'\\goauto\goauto\dotnet\Hub_Data\Reports'
#dest = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports'
#os.chdir(src)



########## Prodct-wise status check & reports fetching ###########


class Command(BaseCommand):
    args = '<foo bar ...>'
    help = 'our help string comes here'

    ############################ Update PSE Reports ###########################
    def update_PSEBuildsStatus(self):
        print("PSE")

        src_hub = r'\\goauto\GoautoReports\PSEEditor'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\PSE'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(PSEStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
                        
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                #print(FQfilename)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))
                    

                    #Filter out UTF-8 characters
                    with io.open(FQfilename, 'r') as f:
                        text = f.read()

                    ## This writes the file as UTF 8
                    with io.open(os.path.join(dest_hub,file), 'w', encoding='utf8') as f:
                        f.write(text)
                        

                    #Copy the file locally to product folder
                    #shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='PSE', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(PSEStatus=True)

    ############################ Update PRE Reports ###########################
    def update_PREBuildsStatus(self):
        print("PRE")

        src_hub = r'\\goauto\goauto\dotnet\PRE_Reports'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\PRE'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(PREStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
                        
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                desFile = file.strip('.xls')+str('.html')
                desPath = os.path.join(dest_hub,desFile)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))

                    #Convert xls to html
                    wb = pd.read_excel(FQfilename) # This reads in your excel doc as a pandas DataFrame
                    wb.to_html(desPath) # Export the DataFrame (Excel doc) to an html file
                    
                    #Copy the file locally to product folder
                    #shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='PRE', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(PREStatus=True)

                    
    ############################ Update EO Reports ###########################
    def update_EOBuildsStatus(self):
        print("EO")

        src_hub = r'\\goauto\GoautoReports\EO'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\EO'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(EOStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
            
            
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                #print(FQfilename)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))

                    #Copy the file locally to product folder
                    shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='EO', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(EOStatus=True)

    ############################ Update Hub Reports ###########################
    def update_HubBuildsStatus(self):
        print("Hub")

        src_hub = r'\\goauto\goauto\dotnet\Hub_Data\Reports'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\Hub'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(HubStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
            
            
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                #print(FQfilename)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))

                    #Copy the file locally to product folder
                    shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='Hub', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(HubStatus=True)
                    
                    
    ############################ Update AC Reports ###########################
    def update_ACBuildsStatus(self):
        print("AC")

        src_hub = r'\\goauto\goauto\dotnet\AC_Reports'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\AC'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(ACStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
            
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                #print(FQfilename)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))

                    #Copy the file locally to product folder
                    shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='AC', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(ACStatus=True)

        
        
    ############################ Update PSE_Installer Reports ###########################
    def update_InstallerPSEBuildsStatus(self):
        print("Installer PSE")

        src_hub = r'\\GOAUTO\goauto\dotnet\Installer_Reports\Installer_PSE'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\Installer_PSE'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(Installer_PSEStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
            
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                #print(FQfilename)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))

                    #Copy the file locally to product folder
                    shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='Installer_PSE', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(Installer_PSEStatus=True)

    ############################ Update PRE_Installer Reports ###########################
    def update_InstallerPREBuildsStatus(self):
        print("Installer PRE")

        src_hub = r'\\GOAUTO\goauto\dotnet\Installer_Reports\Installer_PRE'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\Installer_PRE'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(Installer_PREStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
            
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                #print(FQfilename)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))

                    #Copy the file locally to product folder
                    shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='Installer_PRE', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(Installer_PREStatus=True)

    ############################ Update Peple Reports ###########################
    def update_PeopleBuildsStatus(self):
        print("People")

        src_hub = r'\\GOAUTO\goauto\dotnet\PeopleAutomation'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\People'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(PeopleStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
            
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                #print(FQfilename)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))

                    #Copy the file locally to product folder
                    shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='People', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(PeopleStatus=True)

    ############################ Update Video_tagging Reports ###########################
    def update_VideoTaggingBuildsStatus(self):
        print("Video Tagging")

        src_hub = r'\\GOAUTO\goauto\dotnet\Video_tagging'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\Video_tagging'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(Video_taggingStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
            
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                #print(FQfilename)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))

                    #Copy the file locally to product folder
                    shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='Video_tagging', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(Video_taggingStatus=True)

    ############################ Update Launch_numbers Reports ###########################
    def update_LaunchNumbersBuildsStatus(self):
        print("Launch Numbers")

        src_hub = r'\\GOAUTO\goauto\dotnet\Launch_numbers'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\Launch_numbers'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(Launch_numbersStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
            
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                #print(FQfilename)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))

                    #Copy the file locally to product folder
                    shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='Launch_numbers', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(Launch_numbersStatus=True)

    ############################ Update OLS Reports ###########################
    def update_OLSBuildsStatus(self):
        print("OLS")

        src_hub = r'\\GOAUTO\goauto\dotnet\OLS'
        dest_hub = r'C:\Users\yagupta\Desktop\website\automate\Templates\automate\Automation Reports\OLS'
        os.chdir(src_hub)
        
        builds = []
        builds = list(Builds_Status.objects.filter(OLSStatus=False).values('BuildNo'))
        #print(builds)
        for build in builds:
            BuildNo = build.get('BuildNo')
            
            for file in os.listdir(src_hub):
                FQfilename = os.path.join(src_hub,file)
                #print(FQfilename)
                
                if os.path.isfile(FQfilename) and BuildNo.strip() in FQfilename.strip():
                    print("Found")
                    #print("Filename: "+str(FQfilename))
                    timeReport = time.ctime(os.path.getmtime(FQfilename))

                    #Copy the file locally to product folder
                    shutil.copy(FQfilename, dest_hub)

                    #Make entry in Builds_Info
                    entry_BI = Builds_Info(BuildNo=BuildNo, Product='OLS', DateTime=timeReport, Report=file)
                    entry_BI.save()
                    
                    #Set HubStatus to True for that buildno in Builds_Status
                    Builds_Status.objects.filter(BuildNo=BuildNo).update(OLSStatus=True)
        
            
    def handle(self, *args, **options):
        self.update_PSEBuildsStatus()
        self.update_PREBuildsStatus()
        self.update_EOBuildsStatus()
        self.update_HubBuildsStatus()
        self.update_ACBuildsStatus()
        self.update_InstallerPSEBuildsStatus()
        self.update_InstallerPREBuildsStatus()
        self.update_PeopleBuildsStatus()
        self.update_VideoTaggingBuildsStatus()
        self.update_LaunchNumbersBuildsStatus()
        self.update_OLSBuildsStatus()




############ Count number of files at source ##############
'''
cpt = sum([len(files) for r, d, files in os.walk(src)])
print(cpt)
'''


